import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import {
  getVerifiedDepositPaymentMaps,
  verifiedDepositPaid,
} from "@/lib/invoices/deposit-payments";
import { tenantInvoiceVisibilityCutoffDate } from "@/lib/billing/tenant-invoice-visibility";

type BillRow = {
  id: string;
  invoice_number: string;
  invoice_date: string;
  invoice_source: string;
  issued_at: string;
  retain_until: string;
  organization_id: string | null;
  tenancy_id: string | null;
  tenant_record_id: string | null;
  property_id: string;
  room_id: string;
  bill_month: string;
  due_date: string;
  amount: number | string;
  gross_rent_amount: number | string;
  referral_credit_amount: number | string;
  deposit_amount: number | string;
  paid_amount: number | string;
  status: string;
  notes: string | null;
  removed_at: string | null;
  removed_by: string | null;
  removal_reason: string | null;
  created_at: string;
};

type InvoiceParty = {
  full_name: string | null;
  phone: string | null;
  email: string | null;
  identity_number?: string | null;
};

type InvoiceProperty = {
  id: string;
  name: string;
  property_code: string | null;
  area: string | null;
  address: string | null;
  is_commercial: boolean;
};

type InvoiceRoom = {
  id: string;
  name: string | null;
  room_number: string | null;
};

type InvoiceTenancy = {
  id: string;
  tenant_id: string;
  status: string;
  contract_start: string | null;
  contract_end: string | null;
  check_in_date: string | null;
  checkout_date: string | null;
};

export type RentalInvoiceReceipt = {
  id: string;
  amount: number;
  paymentDate: string;
  paymentMethod: string;
  referenceNumber: string | null;
  verifiedAt: string | null;
  retainUntil: string | null;
  filePath: string;
  fileName: string;
  contentType: string | null;
  signedUrl: string | null;
};

export type RentalInvoiceLineItem = {
  id: string;
  category: string;
  description: string;
  amount: number;
};

export type RentalInvoiceView = {
  id: string;
  invoiceNumber: string;
  invoiceDate: string;
  retainUntil: string;
  billMonth: string;
  dueDate: string;
  amount: number;
  grossRentAmount: number;
  referralCreditAmount: number;
  depositAmount: number;
  extraChargeAmount: number;
  lineItems: RentalInvoiceLineItem[];
  depositPaidAmount: number;
  invoiceTotal: number;
  invoicePaidAmount: number;
  paidAmount: number;
  outstanding: number;
  status: string;
  invoiceStatus: string;
  invoiceSource: string;
  tenantFacing: boolean;
  notes: string | null;
  removedAt: string | null;
  removedBy: string | null;
  removalReason: string | null;
  tenantName: string;
  tenantPhone: string | null;
  tenantEmail: string | null;
  tenantIdentityNumber: string | null;
  propertyId: string;
  propertyName: string;
  propertyCode: string;
  propertyArea: string | null;
  propertyAddress: string | null;
  propertyIsCommercial: boolean;
  roomId: string;
  roomName: string;
  tenancyId: string | null;
  contractStart: string | null;
  contractEnd: string | null;
  receipts: RentalInvoiceReceipt[];
  receiptCount: number;
};

function numberValue(value: number | string | null | undefined) {
  const parsed = Number(value ?? 0);
  return Number.isFinite(parsed) ? parsed : 0;
}

function billSelect() {
  return [
    "id",
    "invoice_number",
    "invoice_date",
    "invoice_source",
    "issued_at",
    "retain_until",
    "organization_id",
    "tenancy_id",
    "tenant_record_id",
    "property_id",
    "room_id",
    "bill_month",
    "due_date",
    "amount",
    "gross_rent_amount",
    "referral_credit_amount",
    "deposit_amount",
    "paid_amount",
    "status",
    "tenant_facing",
    "notes",
    "removed_at",
    "removed_by",
    "removal_reason",
    "created_at",
  ].join(", ");
}

function receiptContentType(fileName: string) {
  if (/\.pdf$/i.test(fileName)) return "application/pdf";
  if (/\.(?:avif|gif|jpe?g|png|webp)$/i.test(fileName)) return "image/*";
  return null;
}

async function getInvoiceReceipts(
  billIds: string[],
  signUrls: boolean,
) {
  if (!billIds.length) return new Map<string, RentalInvoiceReceipt[]>();

  const supabase = signUrls ? createAdminClient() : await createClient();
  const [{ data: submissions }, { data: utilityTopUps }] = await Promise.all([
    supabase
      .from("payment_submissions")
      .select(
        "id, rent_bill_id, amount, payment_date, payment_method, reference_number, receipt_url, verified_at, retain_until",
      )
      .in("rent_bill_id", billIds)
      .eq("verification_status", "verified")
      .not("receipt_url", "is", null)
      .order("payment_date", { ascending: true })
      .order("created_at", { ascending: true }),
    supabase
      .from("smart_meter_top_up_requests")
      .select(
        "id, rent_bill_id, amount, payment_date, payment_slip_path, payment_slip_name, payment_slip_type, provider_reference, verified_at, credited_at, retain_until",
      )
      .in("rent_bill_id", billIds)
      .eq("status", "credited")
      .not("payment_slip_path", "is", null)
      .order("payment_date", { ascending: true })
      .order("created_at", { ascending: true }),
  ]);

  const submissionIds = (submissions ?? []).map((submission) => submission.id);
  const { data: attachments } = submissionIds.length
    ? await supabase
        .from("payment_attachments")
        .select("payment_submission_id, file_name, content_type")
        .in("payment_submission_id", submissionIds)
    : { data: [] };
  const attachmentBySubmission = new Map(
    (attachments ?? []).map((attachment) => [
      attachment.payment_submission_id,
      attachment,
    ]),
  );
  const signedUrlByPath = new Map<string, string>();

  if (signUrls) {
    const receiptPaths = [
      ...new Set(
        (submissions ?? [])
          .map((submission) => submission.receipt_url)
          .filter((path): path is string => Boolean(path)),
      ),
    ];
    const { data: signedReceipts } = await supabase.storage
      .from("payment-receipts")
      .createSignedUrls(receiptPaths, 60 * 60);

    for (const receipt of signedReceipts ?? []) {
      if (receipt.path && receipt.signedUrl) {
        signedUrlByPath.set(receipt.path, receipt.signedUrl);
      }
    }

    const topUpReceiptPaths = [
      ...new Set(
        (utilityTopUps ?? []).map((topUp) => topUp.payment_slip_path),
      ),
    ];
    const { data: signedTopUpReceipts } = topUpReceiptPaths.length
      ? await supabase.storage
          .from("smart-meter-top-up-slips")
          .createSignedUrls(topUpReceiptPaths, 60 * 60)
      : { data: [] };

    for (const receipt of signedTopUpReceipts ?? []) {
      if (receipt.path && receipt.signedUrl) {
        signedUrlByPath.set(receipt.path, receipt.signedUrl);
      }
    }
  }

  const receiptsByBill = new Map<string, RentalInvoiceReceipt[]>();
  for (const submission of submissions ?? []) {
    if (!submission.rent_bill_id || !submission.receipt_url) continue;
    const attachment = attachmentBySubmission.get(submission.id);
    const fileName =
      attachment?.file_name ??
      submission.receipt_url.split("/").at(-1) ??
      "Payment receipt";
    const receipts = receiptsByBill.get(submission.rent_bill_id) ?? [];
    receipts.push({
      id: submission.id,
      amount: numberValue(submission.amount),
      paymentDate: submission.payment_date,
      paymentMethod: submission.payment_method,
      referenceNumber: submission.reference_number,
      verifiedAt: submission.verified_at,
      retainUntil: submission.retain_until,
      filePath: submission.receipt_url,
      fileName,
      contentType:
        attachment?.content_type ?? receiptContentType(fileName),
      signedUrl: signedUrlByPath.get(submission.receipt_url) ?? null,
    });
    receiptsByBill.set(submission.rent_bill_id, receipts);
  }

  for (const topUp of utilityTopUps ?? []) {
    if (!topUp.rent_bill_id || !topUp.payment_slip_path) continue;
    const receipts = receiptsByBill.get(topUp.rent_bill_id) ?? [];
    receipts.push({
      id: topUp.id,
      amount: numberValue(topUp.amount),
      paymentDate: topUp.payment_date,
      paymentMethod: "bank_transfer",
      referenceNumber: topUp.provider_reference,
      verifiedAt: topUp.credited_at ?? topUp.verified_at,
      retainUntil: topUp.retain_until,
      filePath: topUp.payment_slip_path,
      fileName: topUp.payment_slip_name,
      contentType:
        topUp.payment_slip_type ?? receiptContentType(topUp.payment_slip_name),
      signedUrl: signedUrlByPath.get(topUp.payment_slip_path) ?? null,
    });
    receiptsByBill.set(topUp.rent_bill_id, receipts);
  }

  for (const receipts of receiptsByBill.values()) {
    receipts.sort((left, right) =>
      left.paymentDate.localeCompare(right.paymentDate),
    );
  }

  return receiptsByBill;
}

async function hydrateInvoices(
  bills: BillRow[],
  options: { signReceiptUrls?: boolean } = {},
): Promise<RentalInvoiceView[]> {
  if (!bills.length) return [];

  const supabase = await createClient();
  const propertyIds = [...new Set(bills.map((bill) => bill.property_id))];
  const roomIds = [...new Set(bills.map((bill) => bill.room_id))];
  const tenancyIds = [
    ...new Set(
      bills
        .map((bill) => bill.tenancy_id)
        .filter((id): id is string => Boolean(id)),
    ),
  ];
  const tenantRecordIds = [
    ...new Set(
      bills
        .map((bill) => bill.tenant_record_id)
        .filter((id): id is string => Boolean(id)),
    ),
  ];

  const [propertiesResult, roomsResult, tenanciesResult, recordsResult, lineItemsResult] =
    await Promise.all([
      supabase
        .from("properties")
        .select("id, name, property_code, area, address, is_commercial")
        .in("id", propertyIds),
      supabase
        .from("rooms")
        .select("id, name, room_number")
        .in("id", roomIds),
      tenancyIds.length
        ? supabase
            .from("tenancies")
            .select(
              "id, tenant_id, status, contract_start, contract_end, check_in_date, checkout_date",
            )
            .in("id", tenancyIds)
        : Promise.resolve({ data: [], error: null }),
      tenantRecordIds.length
        ? supabase
            .from("tenant_records")
            .select("id, full_name, phone, email, identification_number")
            .in("id", tenantRecordIds)
        : Promise.resolve({ data: [], error: null }),
      supabase
        .from("rental_invoice_line_items")
        .select("id, rent_bill_id, category, description, amount, created_at")
        .in(
          "rent_bill_id",
          bills.map((bill) => bill.id),
        )
        .order("created_at", { ascending: true }),
    ]);

  const tenancies = (tenanciesResult.data ?? []) as InvoiceTenancy[];
  const tenantIds = [...new Set(tenancies.map((tenancy) => tenancy.tenant_id))];
  const tenantsResult = tenantIds.length
    ? await supabase
        .from("tenants")
        .select("id, full_name, phone, email, identity_number")
        .in("id", tenantIds)
    : { data: [], error: null };

  const propertyById = new Map(
    ((propertiesResult.data ?? []) as InvoiceProperty[]).map((property) => [
      property.id,
      property,
    ]),
  );
  const roomById = new Map(
    ((roomsResult.data ?? []) as InvoiceRoom[]).map((room) => [room.id, room]),
  );
  const tenancyById = new Map(
    tenancies.map((tenancy) => [tenancy.id, tenancy]),
  );
  const tenantById = new Map(
    ((tenantsResult.data ?? []) as Array<InvoiceParty & { id: string }>).map(
      (tenant) => [tenant.id, tenant],
    ),
  );
  const tenantRecordById = new Map(
    (
      (recordsResult.data ?? []) as Array<
        InvoiceParty & { id: string; identification_number: string | null }
      >
    ).map((record) => [record.id, record]),
  );
  const depositPaymentMaps = await getVerifiedDepositPaymentMaps(
    supabase,
    tenancyIds,
    tenantRecordIds,
  );
  const receiptsByBill = await getInvoiceReceipts(
    bills.map((bill) => bill.id),
    options.signReceiptUrls ?? false,
  );
  const lineItemsByBill = new Map<string, RentalInvoiceLineItem[]>();
  for (const item of lineItemsResult.data ?? []) {
    const lineItems = lineItemsByBill.get(item.rent_bill_id) ?? [];
    lineItems.push({
      id: item.id,
      category: item.category,
      description: item.description,
      amount: numberValue(item.amount),
    });
    lineItemsByBill.set(item.rent_bill_id, lineItems);
  }

  const invoices = bills.map((bill) => {
    const property = propertyById.get(bill.property_id);
    const room = roomById.get(bill.room_id);
    const tenancy = bill.tenancy_id
      ? tenancyById.get(bill.tenancy_id)
      : undefined;
    const canonicalTenant = tenancy
      ? tenantById.get(tenancy.tenant_id)
      : undefined;
    const importedTenant = bill.tenant_record_id
      ? tenantRecordById.get(bill.tenant_record_id)
      : undefined;
    const tenant = canonicalTenant ?? importedTenant;
    const amount = numberValue(bill.amount);
    const referralCreditAmount = numberValue(bill.referral_credit_amount);
    const grossRentAmount =
      numberValue(bill.gross_rent_amount) || amount + referralCreditAmount;
    const paidAmount = numberValue(bill.paid_amount);
    const depositAmount = numberValue(bill.deposit_amount);
    const depositPaidAmount = verifiedDepositPaid(depositPaymentMaps, {
      tenancyId: bill.tenancy_id,
      tenantRecordId: bill.tenant_record_id,
      depositAmount,
    });
    const lineItems = lineItemsByBill.get(bill.id) ?? [];
    const extraChargeAmount = lineItems.reduce(
      (total, item) => total + item.amount,
      0,
    );
    const invoiceTotal = amount + depositAmount + extraChargeAmount;
    const invoicePaidAmount = Math.min(
      paidAmount + depositPaidAmount,
      invoiceTotal,
    );
    const outstanding = ["cancelled", "waived"].includes(bill.status)
      ? 0
      : Math.max(invoiceTotal - invoicePaidAmount, 0);
    const invoiceStatus = ["cancelled", "waived"].includes(bill.status)
      ? bill.status
      : outstanding <= 0.005
        ? "paid"
        : invoicePaidAmount > 0
          ? "partial"
          : bill.status;
    const receipts = receiptsByBill.get(bill.id) ?? [];

    return {
      id: bill.id,
      invoiceNumber: bill.invoice_number,
      invoiceDate: bill.invoice_date,
      retainUntil: bill.retain_until,
      billMonth: bill.bill_month,
      dueDate: bill.due_date,
      amount,
      grossRentAmount,
      referralCreditAmount,
      depositAmount,
      extraChargeAmount,
      lineItems,
      depositPaidAmount,
      invoiceTotal,
      invoicePaidAmount,
      paidAmount,
      outstanding,
      status: bill.status,
      invoiceStatus,
      invoiceSource: bill.invoice_source,
      tenantFacing: bill.tenant_facing !== false,
      notes: bill.notes,
      removedAt: bill.removed_at,
      removedBy: bill.removed_by,
      removalReason: bill.removal_reason,
      tenantName: tenant?.full_name ?? "Tenant",
      tenantPhone: tenant?.phone ?? null,
      tenantEmail: tenant?.email ?? null,
      tenantIdentityNumber:
        canonicalTenant?.identity_number ??
        importedTenant?.identification_number ??
        null,
      propertyId: bill.property_id,
      propertyName: property?.name ?? "Property",
      propertyCode: property?.property_code ?? "",
      propertyArea: property?.area ?? null,
      propertyAddress: property?.address ?? null,
      propertyIsCommercial: Boolean(property?.is_commercial),
      roomId: bill.room_id,
      roomName: room?.room_number ?? room?.name ?? "Room",
      tenancyId: bill.tenancy_id,
      contractStart:
        tenancy?.check_in_date ?? tenancy?.contract_start ?? null,
      contractEnd:
        tenancy?.checkout_date ?? tenancy?.contract_end ?? null,
      receipts,
      receiptCount: receipts.length,
    };
  });

  const closedStatuses = new Set([
    "ended",
    "terminated",
    "completed",
    "cancelled",
  ]);

  return invoices.filter((invoice) => {
    const tenancy = invoice.tenancyId
      ? tenancyById.get(invoice.tenancyId)
      : undefined;
    const isCheckedOut =
      Boolean(tenancy?.checkout_date) ||
      Boolean(tenancy?.status && closedStatuses.has(tenancy.status));

    return (
      !isCheckedOut ||
      // tenantFacing=false invoices exist specifically so admin/accounting can
      // review a checked-out tenant's historical invoice (e.g. one created by
      // QR bank reconciliation) - the opposite of what this filter otherwise
      // hides. Never suppress them from the admin archive.
      !invoice.tenantFacing ||
      ["paid", "cancelled", "waived"].includes(invoice.invoiceStatus)
    );
  });
}

export async function getHistoricalInvoiceOptions() {
  const supabase = await createClient();
  const [tenantRecordsResult, propertiesResult, roomsResult] = await Promise.all([
    supabase
      .from("tenant_records")
      .select(
        "id, full_name, phone, status, property_id, room_id, monthly_rent, tenancy_id",
      )
      .order("full_name", { ascending: true }),
    supabase
      .from("properties")
      .select("id, name, property_code")
      .order("name", { ascending: true }),
    supabase
      .from("rooms")
      .select("id, property_id, name, room_number")
      .order("room_number", { ascending: true }),
  ]);

  const properties = (propertiesResult.data ?? []).map((property) => ({
    id: property.id,
    name: property.name,
    code: property.property_code,
  }));
  const propertyById = new Map(
    properties.map((property) => [property.id, property]),
  );
  const rooms = (roomsResult.data ?? [])
    .map((room) => ({
      id: room.id,
      propertyId: room.property_id,
      name: room.room_number ?? room.name ?? "Room",
    }))
    .sort((left, right) =>
      left.name.localeCompare(right.name, undefined, {
        numeric: true,
        sensitivity: "base",
      }),
    );
  const roomById = new Map(rooms.map((room) => [room.id, room]));

  return {
    tenants: (tenantRecordsResult.data ?? []).map((tenant) => {
      const property = tenant.property_id
        ? propertyById.get(tenant.property_id)
        : null;
      const room = tenant.room_id ? roomById.get(tenant.room_id) : null;
      return {
        id: tenant.id,
        name: tenant.full_name,
        phone: tenant.phone,
        status: tenant.status,
        propertyId: tenant.property_id,
        propertyName: property?.code ?? property?.name ?? null,
        roomId: tenant.room_id,
        roomName: room?.name ?? null,
        monthlyRent: numberValue(tenant.monthly_rent),
        tenancyId: tenant.tenancy_id,
      };
    }),
    properties,
    rooms,
  };
}

export async function getRentalInvoice(invoiceId: string) {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("rent_bills")
    .select(billSelect())
    .eq("id", invoiceId)
    .maybeSingle();

  if (error || !data) return null;
  return (
    await hydrateInvoices([data as unknown as BillRow], {
      signReceiptUrls: true,
    })
  )[0] ?? null;
}

export async function getRentalInvoiceArchive(input: {
  page?: number;
  pageSize?: number;
  invoiceNumber?: string;
  searchText?: string;
  month?: string;
  status?: string;
}) {
  const supabase = await createClient();
  const page = Math.max(input.page ?? 1, 1);
  const pageSize = Math.min(Math.max(input.pageSize ?? 25, 1), 100);
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;
  const searchText = (input.searchText ?? input.invoiceNumber ?? "")
    .replace(/[%_]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  const searchPattern = `%${searchText}%`;
  const tenantInvoiceCutoffDate = tenantInvoiceVisibilityCutoffDate();

  let query = supabase
    .from("rent_bills")
    .select(billSelect(), { count: "exact" })
    .or(
      `invoice_source.neq.automatic,invoice_source.is.null,due_date.lte.${tenantInvoiceCutoffDate}`,
    )
    .order("bill_month", { ascending: false })
    .order("invoice_number", { ascending: false })
    .order("due_date", { ascending: false })
    .range(from, to);

  if (searchText) {
    const [
      invoiceMatches,
      propertiesByName,
      propertiesByCode,
      roomsByName,
      roomsByNumber,
      tenantMatches,
      tenantRecordMatches,
    ] = await Promise.all([
      supabase
        .from("rent_bills")
        .select("id")
        .ilike("invoice_number", searchPattern),
      supabase
        .from("properties")
        .select("id")
        .ilike("name", searchPattern),
      supabase
        .from("properties")
        .select("id")
        .ilike("property_code", searchPattern),
      supabase
        .from("rooms")
        .select("id")
        .ilike("name", searchPattern),
      supabase
        .from("rooms")
        .select("id")
        .ilike("room_number", searchPattern),
      supabase
        .from("tenants")
        .select("id")
        .ilike("full_name", searchPattern),
      supabase
        .from("tenant_records")
        .select("id")
        .ilike("full_name", searchPattern),
    ]);

    const searchError = [
      invoiceMatches.error,
      propertiesByName.error,
      propertiesByCode.error,
      roomsByName.error,
      roomsByNumber.error,
      tenantMatches.error,
      tenantRecordMatches.error,
    ].find(Boolean);
    if (searchError) {
      throw new Error(searchError.message);
    }

    const tenantIds = (tenantMatches.data ?? []).map((tenant) => tenant.id);
    const { data: tenancyMatches, error: tenancySearchError } = tenantIds.length
      ? await supabase
          .from("tenancies")
          .select("id")
          .in("tenant_id", tenantIds)
      : { data: [], error: null };
    if (tenancySearchError) {
      throw new Error(tenancySearchError.message);
    }

    const ids = (rows: Array<{ id: string }> | null) =>
      [...new Set((rows ?? []).map((row) => row.id))];
    const filterSources: Array<{ column: string; matchingIds: string[] }> = [
      { column: "id", matchingIds: ids(invoiceMatches.data) },
      {
        column: "property_id",
        matchingIds: ids([
          ...(propertiesByName.data ?? []),
          ...(propertiesByCode.data ?? []),
        ]),
      },
      {
        column: "room_id",
        matchingIds: ids([
          ...(roomsByName.data ?? []),
          ...(roomsByNumber.data ?? []),
        ]),
      },
      { column: "tenancy_id", matchingIds: ids(tenancyMatches) },
      {
        column: "tenant_record_id",
        matchingIds: ids(tenantRecordMatches.data),
      },
    ];
    const filters = filterSources
      .filter(({ matchingIds }) => matchingIds.length)
      .map(
        ({ matchingIds, column }) =>
          `${column}.in.(${matchingIds.join(",")})`,
      );

    if (!filters.length) {
      return {
        invoices: [],
        total: 0,
        page,
        pageSize,
      };
    }
    query = query.or(filters.join(","));
  }
  if (input.month && /^\d{4}-\d{2}$/.test(input.month)) {
    query = query.eq("bill_month", `${input.month}-01`);
  }
  if (input.status && input.status !== "all") {
    query = query.eq("status", input.status);
  }

  const { data, count, error } = await query;
  if (error) {
    throw new Error(error.message);
  }

  return {
    invoices: await hydrateInvoices((data ?? []) as unknown as BillRow[], {
      signReceiptUrls: true,
    }),
    total: count ?? 0,
    page,
    pageSize,
  };
}
