'use client';
import { useMemo, useState, useTransition } from 'react';
import { useRouter } from 'next/navigation';
import { bankRoomScope, paymentInBankScope, roomInvoicesForBank, type RoomInvoiceOption, type BankRoom } from '@/lib/accounting/bank-room-scope';
import { existingPaymentChoices, canAllocateExistingPayment, canBulkGroupPayments, remainingPaymentAmount, remainingBankAmount, allocationAmount } from '@/lib/accounting/payment-allocation';
import { CONFIDENCE_FILTERS, reconciliationViewGroup, reconciliationViewPriority, type ConfidenceFilter } from '@/lib/accounting/reconciliation-view';
import { rankExistingPayments, directReconciliationPayment, type ExistingPayment, type StatementTransaction } from '@/lib/accounting/tenant-reconciliation';
import { reconcileExistingPayment, unreconcileExistingPayment, refreshExistingPaymentSuggestions, unreconcileLegacyTenantBank, applyBankToRoomInvoice, createAndApplyRoomInvoiceFromBank } from '@/app/reports/actions';
const money = (n:number) => `RM ${n.toFixed(2)}`;
type BulkItem =
  | { bank: StatementTransaction; location: BankRoom; kind: 'payment'; payment: ExistingPayment }
  | { bank: StatementTransaction; location: BankRoom; kind: 'payments'; payments: ExistingPayment[] }
  | { bank: StatementTransaction; location: BankRoom; kind: 'invoice'; invoice: RoomInvoiceOption };
export function TenantPaymentReconciliation({ payments, banks, locked, canUnmatch, invoices = [] }: {payments:ExistingPayment[];banks:StatementTransaction[];locked:boolean;canUnmatch:boolean;invoices?:RoomInvoiceOption[]}) {
  const [search,setSearch]=useState('');
  const [confidenceFilter,setConfidenceFilter]=useState<ConfidenceFilter>('all');
  const [selected,setSelected]=useState<Record<string,string>>({});
  const [activeBank,setActiveBank]=useState<string|null>(null);
  const [message,setMessage]=useState('');
  const [pending,start]=useTransition();
  const router=useRouter();
  const choices=useMemo(()=>existingPaymentChoices(payments),[payments]);
  const suggestions=useMemo(()=>new Map(banks.map(b=>[b.id,rankExistingPayments(b,choices)])),[banks,choices]);
  const paymentById=useMemo(()=>new Map(choices.map(p=>[p.id,p])),[choices]);
  const paymentByBank=useMemo(()=>new Map(payments.filter(p=>p.bankId).map(p=>[p.bankId,p])),[payments]);
  const available=useMemo(()=>choices.filter(p=>p.eligible&&!p.bankId&&!p.legacyMatched),[choices]);
  // Filter the display only: keep the full data for duplicate checks and matching locks.
  const workingBanks=banks.filter(b=>!b.completed&&(b.remainingAmount!==undefined?b.remainingAmount>0:!paymentByBank.has(b.id)));
  const workingPayments=choices.filter(p=>!p.bankId&&!p.legacyMatched&&p.reconciliationStatus!=='RECONCILED');
  // A bank line's own reference/description identifies the correct record two ways: a
  // property+room code (Property + Room + same month), or — when there's no room code — a
  // tenant name or exact bank-reference token that rankExistingPayments already recognizes
  // (the same "identified" concept the manual dropdown's ranking uses). Either way, when
  // exactly one existing confirmed payment is identified this way, it's queued to allocate
  // against that payment — the exact same gate the per-row "Reconcile" button itself uses
  // (canAllocateExistingPayment: eligible, not duplicate, not already used/completed, in scope,
  // and a positive amount to allocate). A bank amount that differs from the payment amount is
  // not a reason to exclude it — that's an ordinary partial payment, and the MIN-of-balances rule
  // (same as the table below) applies whatever the bank amount is. A bare room number with no
  // property code is never guessed at: bank statements carry no property linkage of their own, so
  // that would risk misdirecting money to the wrong property's tenant — only a name/reference match
  // or a full property+room code count as identified. When more than one confirmed payment is
  // identified for the SAME tenant/room (for example a deposit and a separate rent invoice paid
  // together), and canBulkGroupPayments confirms they're unambiguous — same tenant identity and no
  // two candidates share an equal amount that could make them indistinguishable duplicates of one
  // another — the bulk queue combines them into one multi-payment item: the same server-side
  // allocation call runs once per payment, in sequence, against the same bank line (this is the
  // already-supported "one bank to multiple payments" shape; the server recomputes the bank line's
  // live remaining balance before each call, so this is exactly what happens if an admin picked one
  // payment, reconciled, then picked the next). When identified candidates are for different
  // tenants, or two candidates share an equal amount, that ambiguity is never resolved
  // automatically — the line stays out of bulk for manual review, same as today. When no confirmed
  // payment is identified but the bank line names a property+room and that room has exactly one
  // open invoice for the month, it's queued for the direct bank-to-invoice match instead (the
  // exception in AGENTS.md) — the same rule the per-row "Match & Reconcile" button uses. Everything
  // excluded stays in the list below for manual review.
  const bulkReady=useMemo<BulkItem[]>(()=>workingBanks.flatMap((bank):BulkItem[]=>{
    const {hint:location,conflict:roomConflict}=bankRoomScope(bank);
    if(roomConflict||bank.used||bank.duplicate) return [];
    const ranked=suggestions.get(bank.id)??[];
    const identified=ranked.filter(r=>!r.missingIdentity&&!r.locationConflict);
    if(identified.length===1) {
      const payment=identified[0].payment;
      if(!canAllocateExistingPayment(bank,payment)) return [];
      const matchLocation=location??{propertyCode:payment.propertyCode?.trim().toUpperCase()||payment.property,roomCode:payment.room};
      return [{bank,location:matchLocation,kind:'payment' as const,payment}];
    }
    if(identified.length>1) {
      const candidates=identified.map(r=>r.payment);
      if(!canBulkGroupPayments(candidates)) return [];
      const allocatable=candidates.filter(payment=>canAllocateExistingPayment(bank,payment));
      if(!allocatable.length) return [];
      const first=allocatable[0];
      const matchLocation=location??{propertyCode:first.propertyCode?.trim().toUpperCase()||first.property,roomCode:first.room};
      return allocatable.length===1
        ? [{bank,location:matchLocation,kind:'payment' as const,payment:first}]
        : [{bank,location:matchLocation,kind:'payments' as const,payments:allocatable}];
    }
    if(!location) return [];
    const unpaidRoomInvoices=roomInvoicesForBank(bank,invoices).filter(invoice=>invoice.rentOutstanding>0.005);
    if(unpaidRoomInvoices.length!==1) return [];
    const invoice=unpaidRoomInvoices[0];
    if(remainingBankAmount(bank)>invoice.rentOutstanding+0.005) return [];
    return [{bank,location,kind:'invoice' as const,invoice}];
  }),[workingBanks,suggestions,invoices]);
  // Two or more bank lines in this same bulk run can target the same payment or invoice (for
  // example two partial transfers for one tenant's rent). Walk bulkReady in order, tracking a
  // running consumed amount per payment/invoice id, so the preview's "already paid" / "remaining"
  // figures reflect what earlier lines in this run already applied, instead of each row computing
  // its balance independently (which would show the same starting balance twice). The actual
  // reconciliation still runs each line sequentially through the same server-side RPC — which
  // recomputes live balances itself and is already safe from double-allocation — so this is a
  // display-accuracy improvement for the preview table only.
  const bulkPreview=useMemo(()=>{
    const consumedByPayment=new Map<string,number>();
    const consumedByInvoice=new Map<string,number>();
    // A 'payments' item applies one bank line's balance to more than one payment in sequence, so
    // it expands into one preview row per payment, tracking the bank's own remaining balance as it
    // is consumed across that item's rows (separately from the cross-item consumedByPayment map
    // below, which still tracks running consumption across different bank lines in this same run).
    return bulkReady.flatMap((item):{item:BulkItem;rowKey:string;tenant:string;invoiceNo:string|null;invoiceAmount:number;alreadyPaid:number;remainingBefore:number;applied:number;remainingAfter:number}[]=>{
      const {bank}=item;
      if(item.kind==='invoice') {
        const consumed=consumedByInvoice.get(item.invoice.id)??0;
        const remainingBefore=Math.max(item.invoice.rentOutstanding-consumed,0);
        const applied=Math.min(remainingBankAmount(bank),remainingBefore);
        consumedByInvoice.set(item.invoice.id,consumed+applied);
        return [{item,rowKey:`${bank.id}:invoice:${item.invoice.id}`,tenant:item.invoice.tenantName,invoiceNo:item.invoice.invoiceNumber,invoiceAmount:item.invoice.invoiceAmount,alreadyPaid:item.invoice.paidAmount+consumed,remainingBefore,applied,remainingAfter:Math.max(remainingBefore-applied,0)}];
      }
      const paymentsList=item.kind==='payment'?[item.payment]:item.payments;
      let bankLeft=remainingBankAmount(bank);
      return paymentsList.map(payment=>{
        const consumed=consumedByPayment.get(payment.id)??0;
        const remainingBefore=Math.max(remainingPaymentAmount(payment)-consumed,0);
        const applied=Math.min(bankLeft,remainingBefore);
        bankLeft=Math.max(bankLeft-applied,0);
        consumedByPayment.set(payment.id,consumed+applied);
        return {item,rowKey:`${bank.id}:payment:${payment.id}`,tenant:payment.tenant,invoiceNo:payment.invoice,invoiceAmount:payment.amount,alreadyPaid:(payment.reconciledAmount??0)+consumed,remainingBefore,applied,remainingAfter:Math.max(remainingBefore-applied,0)};
      });
    });
  },[bulkReady]);
  const [bulkPending,startBulk]=useTransition();
  function runBulkReconcile() {
    startBulk(async()=>{
      let linesSucceeded=0,linesFailed=0,actionsSucceeded=0,actionsFailed=0;
      for(const item of bulkReady) {
        if(item.kind==='invoice') {
          try {
            const data=new FormData();data.set('lineId',item.bank.id);data.set('billId',item.invoice.id);
            const result=await applyBankToRoomInvoice(data);
            if(result.ok) { linesSucceeded+=1;actionsSucceeded+=1; } else { linesFailed+=1;actionsFailed+=1; }
          } catch { linesFailed+=1;actionsFailed+=1; }
          continue;
        }
        // A 'payments' item allocates the SAME bank line to more than one payment: each call is
        // the exact same reconcileExistingPayment RPC the per-row Reconcile button uses, run in
        // sequence — the server recomputes the bank line's live remaining balance before each one,
        // so this is identical to an admin picking one payment, reconciling, then picking the next.
        const paymentsList=item.kind==='payment'?[item.payment]:item.payments;
        let lineFailures=0;
        for(const payment of paymentsList) {
          try {
            const data=new FormData();data.set('lineId',item.bank.id);data.set('paymentId',payment.id);
            const result=await reconcileExistingPayment(data);
            if(result.ok) actionsSucceeded+=1; else { actionsFailed+=1;lineFailures+=1; }
          } catch { actionsFailed+=1;lineFailures+=1; }
        }
        if(lineFailures) linesFailed+=1; else linesSucceeded+=1;
      }
      const splitNote=actionsSucceeded>linesSucceeded?` (${actionsSucceeded} payment allocations in total — some bank transactions were split across more than one existing payment for the same tenant)`:'';
      setMessage(`Reconciled ${linesSucceeded} of ${bulkReady.length} room-matched transaction${bulkReady.length===1?'':'s'}${splitNote}. Existing confirmed payments were linked, never duplicated; a new confirmed payment was only created for room-matched invoices with no existing payment available.${linesFailed?` ${linesFailed} could not be fully reconciled and remain for manual review — nothing else changed.`:''}`);
      router.refresh();
    });
  }
  const matchesSearch=(value:string)=>value.toLowerCase().includes(search.toLowerCase());
  const searchedRows=workingBanks.filter(b=>matchesSearch(`${b.description} ${b.reference}`)||(suggestions.get(b.id)??[]).some(s=>matchesSearch(`${s.payment.tenant} ${s.payment.property} ${s.payment.room} ${s.payment.invoice} ${s.payment.receipt}`))||roomInvoicesForBank(b,invoices).some(i=>matchesSearch(`${i.tenantName} ${i.invoiceNumber} ${i.propertyCode} ${i.roomCode}`))).map(bank=>{
    const ranked=suggestions.get(bank.id)??[];
    const selectedPayment=paymentById.get(selected[bank.id]);
    const group=reconciliationViewGroup(bank,ranked,selectedPayment);
    const confidence=(selectedPayment?ranked.find(item=>item.payment.id===selectedPayment.id):ranked[0])?.confidence;
    return {bank,group,priority:reconciliationViewPriority(group,confidence)};
  });
  const visibleBanks=searchedRows.filter(row=>confidenceFilter==='all'||row.group===confidenceFilter)
    .sort((a,b)=>a.priority-b.priority).map(row=>row.bank);
  function run(bankId:string,paymentId:string,unmatch=false) {
    const reason=unmatch ? window.prompt('Reason for unmatching this payment:') : null;
    if(unmatch && !reason) return;
    start(async()=>{
      try {
      const data=new FormData();data.set('lineId',bankId);data.set('paymentId',paymentId);if(reason)data.set('reason',reason);
      const result=await (unmatch ? paymentId ? unreconcileExistingPayment(data) : unreconcileLegacyTenantBank(data) : reconcileExistingPayment(data));
      setMessage(result.ok ? (unmatch?'Unmatched. Existing payment and receipt unchanged.':'RECONCILED — existing payment linked; nothing posted again.') : result.error);
      if(result.ok) { setSelected(previous=>{const next={...previous};delete next[bankId];return next;});router.refresh(); }
      } catch { setMessage('Unable to confirm the result. Refresh this page before retrying. Duplicate protection remains active.'); }
    });
  }
  // Only when the bank line's own reference/description names exactly one room (no conflict),
  // that room has exactly one still-open invoice for the same month, no confirmed payment is
  // already available to link, and the bank amount fits the invoice balance. The database
  // function re-checks all of this itself before creating anything.
  function runDirect(bankId:string,billId:string) {
    start(async()=>{
      try {
        const data=new FormData();data.set('lineId',bankId);data.set('billId',billId);
        const result=await applyBankToRoomInvoice(data);
        setMessage(result.ok ? 'RECONCILED — bank payment applied directly to this room’s invoice. A new confirmed payment was created from the bank evidence.' : result.error);
        if(result.ok) router.refresh();
      } catch { setMessage('Unable to confirm the result. Refresh this page before retrying. Duplicate protection remains active.'); }
    });
  }
  // No existing invoice already covers this room+month (or none fits), but the
  // bank line's own reference names exactly one room. Resolve which tenancy
  // occupied that room on the bank transaction's own date (not necessarily the
  // room's current tenant), reuse that tenancy's invoice for the month if one
  // already exists, or create it - then reconcile, all inside one server-side
  // transaction. A checked-out tenant's invoice created this way never becomes
  // a new tenant-facing bill for them; the database decides that, not this button.
  function runCreateAndApply(bankId:string) {
    start(async()=>{
      try {
        const data=new FormData();data.set('lineId',bankId);
        const result=await createAndApplyRoomInvoiceFromBank(data);
        setMessage(result.ok ? 'RECONCILED — matching rental invoice found or created from tenancy history and reconciled against the bank evidence.' : result.error);
        if(result.ok) router.refresh();
      } catch { setMessage('Unable to confirm the result. Refresh this page before retrying. Duplicate protection remains active.'); }
    });
  }
  return <section className="space-y-3 rounded-lg border bg-white p-4" id="bank-transactions">
    <h2 className="text-lg font-semibold">Tenant payments ↔ Bank statement</h2>
    <p className="text-sm font-medium">{workingBanks.length} bank transactions still in process. Completed items leave this page; view completed accounting entries in the ledger.</p>
    <p className="text-sm text-slate-600">Link existing records only. No new payment, receipt or Accounts Receivable posting. Suggestions never reconcile automatically.</p>
    <p className="text-sm text-slate-600">Clear matches with a receipt or slip are ready: View Receipt, check the tenant and amount, then press Reconcile. Use Manual Match when proof is missing or the match needs review.</p>
    <p className="text-sm text-slate-600">Transfers can match the bank transaction reference saved during verification, tenant name or QR property / room. Without one of these, use Manual Match; amount and date alone never identify a tenant.</p>
    <p className="text-sm text-blue-900">When the bank identifies a property and room, only that room’s payments and invoices for the bank month are shown. Paid invoices remain visible; invoice balance does not decide whether an existing payment can be reconciled.</p>
    <p className="text-sm text-blue-900">Rent, deposit and other allocations from one verified slip are matched together. Select the verified slip to reconcile the smaller of the payment balance and bank balance. Any remainder stays available. Invoice outstanding is not used, and no payment is recorded again.</p>
    {bulkReady.length ? <div className="space-y-3 rounded-lg border border-emerald-200 bg-emerald-50 p-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="font-semibold text-emerald-950">Ready to reconcile by room match ({bulkReady.length})</h3>
          <p className="text-sm text-emerald-800">Each bank line&rsquo;s own reference/description is checked for a property+room code, a tenant name, or an exact bank-reference match to an existing confirmed payment — the same month as the bank line, always. When exactly one confirmed payment is identified this way, it&rsquo;s matched here automatically — a bank amount that differs from the payment amount is treated as an ordinary partial payment, never a reason to hold it for manual review. When more than one confirmed payment is identified for the SAME tenant and room — a deposit and a separate rent invoice paid together, for example — the bank line is matched to all of them here, applied one after another (shown as one row per payment below); this never happens when the candidates are for different tenants, or when two of them share the exact same amount and so could be indistinguishable duplicates of each other — those stay below for manual review. A bare room number with no property code is never guessed at, since bank statements carry no property of their own. When no confirmed payment is identified but the bank line names a property and room with exactly one open invoice for the month, the bank evidence is matched straight to that invoice instead. Everything else stays in the list below for you to match by hand.</p>
        </div>
        <button type="button" disabled={locked||pending||bulkPending} className="whitespace-nowrap rounded bg-emerald-700 px-4 py-2 text-sm font-semibold text-white disabled:opacity-40" onClick={runBulkReconcile}>{bulkPending?'Reconciling…':`Reconcile all ${bulkReady.length} now`}</button>
      </div>
      <div className="max-h-64 overflow-auto rounded border bg-white">
        <table className="w-full text-left text-xs"><thead className="sticky top-0 bg-slate-100"><tr>{['Tenant','Property / Room','Invoice','Invoice amount','Already paid','Remaining before','Bank amount','Remaining after','Bank reference'].map(h=><th key={h} className="p-2">{h}</th>)}</tr></thead>
          <tbody>{bulkPreview.map(row=>{
            const {item,rowKey,tenant,invoiceNo,invoiceAmount,alreadyPaid,remainingBefore,applied,remainingAfter}=row;
            const {bank,location}=item;
            return <tr key={rowKey} className="border-t">
            <td className="p-2">{tenant}</td>
            <td className="p-2">{location.propertyCode} / Room {location.roomCode}</td>
            <td className="p-2">{invoiceNo||'—'}</td>
            <td className="p-2 whitespace-nowrap">{money(invoiceAmount)}</td>
            <td className="p-2 whitespace-nowrap">{money(alreadyPaid)}</td>
            <td className="p-2 whitespace-nowrap">{money(remainingBefore)}</td>
            <td className="p-2 whitespace-nowrap">{money(applied)} · {bank.date}</td>
            <td className="p-2 whitespace-nowrap font-semibold">{money(remainingAfter)}</td>
            <td className="p-2">{bank.reference||bank.description.slice(0,50)}{item.kind!=='invoice'?<span className="block text-slate-500">Existing payment{item.kind==='payments'?' · split across '+item.payments.length+' payments':''}</span>:null}</td>
          </tr>;})}</tbody>
        </table>
      </div>
    </div> : null}
    <button type="button" disabled={pending||locked} className="rounded border px-3 py-2 text-sm disabled:opacity-40" onClick={()=>start(async()=>{try{const result=await refreshExistingPaymentSuggestions();setMessage(result.ok?'Suggestions refreshed. No payments or receipts changed.':result.error);if(result.ok)router.refresh();}catch{setMessage('Unable to refresh suggestions. Please retry.');}})}>Refresh match suggestions</button>
    <input aria-label="Search reconciliation" className="w-full rounded border p-2" placeholder="Search tenant, property, room, invoice, receipt or bank reference" value={search} onChange={e=>setSearch(e.target.value)}/>
    {message ? <p role="status" className="rounded bg-blue-50 p-2 text-sm">{message}</p>:null}
    <div className="max-h-[65vh] overflow-auto rounded border"><table className="w-full text-left text-xs"><thead className="sticky top-0 z-10 bg-slate-100"><tr><th colSpan={9} className="border-b bg-white p-2 font-normal">
      <div className="flex flex-wrap items-center gap-2" role="group" aria-label="Filter reconciliation by confidence">
        <span className="font-semibold">Confidence filter:</span>
        {CONFIDENCE_FILTERS.map(filter=><button key={filter.value} type="button" aria-pressed={confidenceFilter===filter.value}
          className={`rounded-full border px-3 py-1.5 text-xs font-semibold focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-emerald-700 ${confidenceFilter===filter.value?'border-emerald-700 bg-emerald-700 text-white':'border-slate-300 bg-white text-slate-700 hover:bg-slate-100'}`}
          onClick={()=>setConfidenceFilter(filter.value)}>{filter.label} ({filter.value==='all'?searchedRows.length:searchedRows.filter(row=>row.group===filter.value).length})</button>)}
        <span className="text-slate-600" role="status">Showing {visibleBanks.length} of {workingBanks.length} · Highest confidence first</span>
      </div>
    </th></tr><tr>
      {['Existing tenant payment / receipt','Property / Room','Invoice / Receipt No.','Receipt amount / date','Payment reference / AR','Bank amount / date','Bank description / reference','Confidence / Status','Action'].map(h=><th key={h} className="p-2">{h}</th>)}
    </tr></thead><tbody>{!visibleBanks.length?<tr><td colSpan={9} className="p-6 text-center text-slate-600">{!workingBanks.length?'No bank transactions left to reconcile in this statement.':confidenceFilter!=='all'?'No transactions match this confidence filter. Choose All to see the other items.':'No in-process transactions match your search.'}</td></tr>:null}{visibleBanks.map(bank=>{
      const linked=bank.completed?paymentByBank.get(bank.id):undefined;
      const {hint:bankLocation,conflict:roomConflict}=bankRoomScope(bank);
      const ranked=suggestions.get(bank.id)??[];
      // With a property+room code, every same-month in-scope payment is shown (unchanged). Without
      // one, never fall back to all same-month tenants — only payments rankExistingPayments already
      // identified by tenant name or an exact bank-reference match are offered.
      const roomPayments=bankLocation?available.filter(p=>paymentInBankScope(bank,p)):ranked.filter(r=>!r.missingIdentity&&!r.locationConflict).map(r=>r.payment);
      const roomInvoices=roomInvoicesForBank(bank,invoices);
      const readyPayment=directReconciliationPayment(bank,ranked);
      const chosenPayment=paymentById.get(selected[bank.id])??readyPayment;
      const payment=linked ?? paymentById.get(selected[bank.id]) ?? (ranked[0]?.missingIdentity?undefined:ranked[0]?.payment);
      const suggestion=payment ? ranked.find(s=>s.payment.id===payment.id) : ranked[0];
      const same=payment && Math.round(remainingPaymentAmount(payment)*100)===Math.round(remainingBankAmount(bank)*100);
      const allocatable=canAllocateExistingPayment(bank,chosenPayment);
      const duplicate=bank.duplicate||payment?.duplicate;
      const status=linked?'RECONCILED':bank.used||duplicate||roomConflict?'MANUAL_REVIEW':payment ? suggestion?.status ?? 'MANUAL_REVIEW' : ranked[0]?.status ?? 'UNMATCHED BANK TRANSACTION';
      // No confirmed payment exists to link (the case above never applies), but the bank line's
      // own reference names exactly one room with exactly one open invoice for the same month
      // and the amount fits — offer to apply the bank evidence straight to that invoice.
      const unpaidRoomInvoices=roomInvoices.filter(invoice=>invoice.rentOutstanding>0.005);
      const directInvoice=bankLocation&&!roomConflict&&!linked&&!bank.used&&!duplicate&&!roomPayments.length
        &&unpaidRoomInvoices.length===1&&remainingBankAmount(bank)<=unpaidRoomInvoices[0].rentOutstanding+0.005
        ?unpaidRoomInvoices[0]:null;
      return <tr key={bank.id} className={`border-t ${linked?'bg-emerald-50':''}`}>
        <td className="min-w-64 p-2">{linked ? linked.tenant : <><strong className="block">{payment?.tenant??'No matching receipt selected'}</strong>{readyPayment&&!selected[bank.id]?<span className="block text-emerald-700">Ready to reconcile</span>:null}
          {bankLocation?<p className="mt-1 font-semibold text-blue-900">Matching only {bankLocation.propertyCode} / Room {bankLocation.roomCode} · {bank.date.slice(0,7)}</p>:null}
          {roomConflict?<p className="text-red-700">Conflicting property / room references. Review the bank transaction before matching.</p>:null}
          {!bankLocation?<button type="button" disabled={bank.used||locked||pending||roomConflict} className="text-blue-700 underline disabled:opacity-40" onClick={()=>setActiveBank(activeBank===bank.id?null:bank.id)}>{readyPayment?'Change match':'Manual Match'}</button>:null}
          {(activeBank===bank.id||bankLocation)&&!roomConflict?<select aria-label={`Existing payment for ${bank.reference || bank.id}`} className="mt-1 w-full rounded border p-1" value={selected[bank.id]??readyPayment?.id??''} onChange={e=>setSelected(previous=>({...previous,[bank.id]:e.target.value}))} disabled={bank.used||locked||pending||!roomPayments.length}><option value="">{roomPayments.length?'Select existing payment':'No available confirmed payment'}</option>{roomPayments.map(p=><option value={p.id} key={p.id} disabled={p.duplicate}>{p.tenant} · {p.invoice||'No linked invoice'} · {money(p.amount)}{p.allocationParts?' combined slip':''} · {money(remainingPaymentAmount(p))} left to reconcile · {p.date} · {p.reference||p.receipt||p.id.slice(0,8)}</option>)}</select>:null}
          {payment?.allocationParts?<p className="mt-1 font-semibold text-emerald-800">Same verified slip: {payment.allocationParts.map(p=>money(p.amount)).join(' + ')} = {money(payment.amount)}</p>:null}
          {payment?.allocationParts && new Set(payment.allocationParts.map(p=>p.invoiceId)).size>1?<details className="mt-1"><summary>Existing invoice allocations</summary>{payment.allocationParts.map(part=><p key={part.id}>{part.invoice||'No linked invoice'} · {money(part.amount)} · {money(part.remaining)} left to reconcile</p>)}</details>:null}
          {payment&&(payment.reconciledAmount??0)>0?<p>Already reconciled: {money(payment.reconciledAmount!)} · Still to reconcile: {money(remainingPaymentAmount(payment))}</p>:null}
          {allocatable&&chosenPayment?<p className="mt-1 font-semibold text-emerald-800">Reconcile {money(allocationAmount(bank,chosenPayment))} now<br/>Payment remaining after: {money(remainingPaymentAmount(chosenPayment)-allocationAmount(bank,chosenPayment))}<br/>Bank remaining after: {money(remainingBankAmount(bank)-allocationAmount(bank,chosenPayment))}</p>:null}
          {bankLocation?<div className="mt-2 rounded border border-blue-200 bg-blue-50 p-2 text-xs"><strong>This room’s {bank.date.slice(0,7)} invoice{roomInvoices.length===1?'':'s'}</strong>{roomInvoices.map(invoice=><p key={invoice.id} className="mt-1"><a href={`/invoices/${invoice.id}`} target="_blank" rel="noreferrer" className="text-blue-700 underline">{invoice.invoiceNumber||'View invoice'}</a> · {invoice.tenantName}<br/>Rent / charges balance: {money(invoice.rentOutstanding)}</p>)}{!roomInvoices.length?<p>No invoice found for this room and bank month. Other rooms will not be substituted.</p>:null}{!roomPayments.length?<p className="mt-1">No available confirmed payment for this room and month. The invoice is shown for reference; no new payment or receipt was created.</p>:null}{directInvoice?<div className="mt-2 flex flex-wrap items-center justify-between gap-2 rounded border border-emerald-300 bg-emerald-50 p-2"><span className="text-emerald-900">Bank reference clearly matches this room — apply {money(remainingBankAmount(bank))} straight to this invoice?</span><button type="button" disabled={locked||pending} className="whitespace-nowrap rounded bg-emerald-700 px-3 py-1.5 text-white disabled:opacity-40" onClick={()=>runDirect(bank.id,directInvoice.id)}>Match &amp; Reconcile</button></div>:null}
          {!directInvoice&&!roomPayments.length&&!bank.used&&!duplicate?<div className="mt-2 flex flex-wrap items-center justify-between gap-2 rounded border border-amber-300 bg-amber-50 p-2"><span className="text-amber-900">No suitable invoice found yet — resolve which tenancy occupied this room on {bank.date} (checking tenancy history, not just the current occupant), then find or create that tenancy&rsquo;s {bank.date.slice(0,7)} invoice and reconcile {money(remainingBankAmount(bank))} to it?</span><button type="button" disabled={locked||pending} className="whitespace-nowrap rounded bg-amber-700 px-3 py-1.5 text-white disabled:opacity-40" onClick={()=>runCreateAndApply(bank.id)}>Find/Create Invoice &amp; Reconcile</button></div>:null}</div>:null}
        </>}</td>
        <td className="p-2">{bankLocation?.propertyCode??payment?.property??'—'}<br/>{bankLocation?`Room ${bankLocation.roomCode}`:payment?.room}</td><td className="p-2">{payment?.invoice|| (roomInvoices.length ? roomInvoices.map(invoice=><a key={invoice.id} href={`/invoices/${invoice.id}`} target="_blank" rel="noreferrer" className="block text-blue-700 underline">{invoice.invoiceNumber||'View invoice'}</a>) : '—')}<br/>{payment?.receipt||'No receipt number'}</td>
        <td className="p-2 whitespace-nowrap">{payment?money(payment.amount):'—'}<br/>{payment?.date}</td><td className="max-w-48 break-words p-2">{payment?.reference||'—'}<details><summary>AR reference</summary>{payment?.arReference||'Select payment'}</details></td>
        <td className="whitespace-nowrap p-2">{money(bank.amount)}<br/>{bank.date}<br/>Allocated: {money(bank.allocatedAmount??0)}<br/><strong>Remaining: {money(remainingBankAmount(bank))}</strong></td><td className="max-w-64 p-2"><details><summary className="cursor-pointer">View Bank Transaction</summary>{bank.description}<br/>{bank.reference}<br/>{bank.id}</details><span>{bank.reference||bank.description.slice(0,55)}</span></td>
        <td className="p-2"><strong>{status}</strong>{suggestion?<p className="text-slate-600">{suggestion.matchReason}</p>:null}<br/>{!linked?suggestion?.confidence??(payment?'Manual Review':null):null}{duplicate?<p className="text-red-700">Possible duplicate transaction. Please review.</p>:null}{suggestion?.locationConflict?<p className="text-red-700">Bank property / room reference differs. Check the correct tenant.</p>:null}{bank.used&&!linked?<p>Existing allocation — locked for review.</p>:null}{payment&&!same?<p className="text-blue-900">{allocatable?'Selected verified slip — partial allocation allowed. The remaining balance stays available.':'Check the verified slip, then select it above. Different totals do not prevent partial reconciliation.'}</p>:null}</td>
        <td className="min-w-36 p-2">{linked ? canUnmatch?<button type="button" disabled={pending} className="text-red-700 underline" onClick={()=>run(bank.id,linked.id,true)}>Unmatch</button>:null : <button type="button" disabled={!allocatable||locked||pending} className="rounded bg-emerald-700 px-3 py-2 text-white disabled:opacity-40" onClick={()=>chosenPayment&&run(bank.id,chosenPayment.id)}>Reconcile</button>}
          {payment?<details className="mt-1"><summary>View Receipt</summary><div className="mt-2 space-y-1 rounded border bg-white p-2"><strong>{payment.tenant}</strong><p>{payment.property} / {payment.room}</p><p>Invoice: {payment.invoice||'—'}<br/>Receipt: {payment.receipt||'No receipt number assigned'}</p><p>Receipt amount: {money(payment.amount)}<br/>Bank amount: {money(bank.amount)}</p><p>Payment date: {payment.date}<br/>Bank date: {bank.date}</p><p>Payment reference: {payment.reference||'—'}<br/>Bank reference: {bank.reference||bank.description}</p>{payment.slipUrl?<a className="block text-blue-700 underline" target="_blank" rel="noreferrer" href={payment.slipUrl}>Open original payment slip</a>:null}<p>Existing payment {payment.id}<br/>Tenant status (unchanged): {payment.tenantStatus}</p></div></details>:null}
          {payment?.slipUrl?<a className="block text-blue-700 underline" target="_blank" rel="noreferrer" href={payment.slipUrl}>View Slip</a>:null}
          {!linked&&bank.legacyPaymentLinks?.length?<details className="mt-1"><summary>Review existing allocation</summary>{bank.legacyPaymentLinks.map(link=><p key={`${link.sourceType}:${link.sourceId}`}>{paymentById.get(link.sourceId)?.tenant??link.sourceType} · {money(link.amount)} · {link.sourceId}</p>)}{canUnmatch?<button type="button" disabled={pending} className="text-red-700 underline" onClick={()=>run(bank.id,'',true)}>Unmatch legacy links</button>:null}</details>:null}
        </td></tr>;
    })}</tbody></table></div>
    <details><summary className="cursor-pointer font-semibold">Payments / receipts still to reconcile ({workingPayments.length})</summary>
      <p className="py-2 text-xs text-slate-600">Slips awaiting an existing confirmed payment are read-only here. Continue to use your normal payment verification; reconciliation does not create or verify tenant payments.</p>
      <div className="max-h-80 overflow-auto"><table className="w-full text-left text-xs"><thead><tr>{['Tenant','Property / Room','Invoice','Receipt','Amount / Date','Reference','Reconciliation status','Slip'].map(h=><th className="p-2" key={h}>{h}</th>)}</tr></thead><tbody>{workingPayments.filter(p=>matchesSearch(`${p.tenant} ${p.property} ${p.room} ${p.invoice} ${p.receipt} ${p.reference}`)).map(p=><tr className="border-t" key={p.id}><td className="p-2">{p.tenant}</td><td>{p.property} / {p.room}</td><td>{p.invoice||'—'}</td><td>{p.receipt||'—'}</td><td>{money(p.amount)} / {p.date}</td><td>{p.reference||'—'}</td><td>{p.reconciliationStatus}{!p.eligible?' — existing payment not confirmed / reversed':''}</td><td>{p.slipUrl?<a href={p.slipUrl} target="_blank" rel="noreferrer">View Slip</a>:'—'}</td></tr>)}</tbody></table></div>
    </details>
  </section>;
}
